/* $begin shellmain */
#include "csapp.h"
#include <errno.h>
#define MAXARGS 128

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void sigchld_handler(int sig);
void sigtstp_handler(int sig);
void sigint_handler(int sig);
void sigquit_handler(int sig);
void delete_process(int now);

struct prlist
{
    pid_t pid;
    int status; //0 : forground 1 : background 2 : suspend -1 : nop
    int printable;
    int order;
    char cmdline[MAXLINE];
} prlist[100];
int prcnt = 0;
int nextorder = 1;

char ready_to_print[100][100];
int print_idx = 0;

int main()
{
    char cmdline[MAXLINE]; /* Command line */
    signal(SIGINT, sigint_handler);
    signal(SIGTSTP, sigtstp_handler);
    signal(SIGCHLD, sigchld_handler);
    //Signal(SIGQUIT, sigquit_handler);

    while (1)
    {
        /* Read */
        printf("CSE4100:P4-myshell> ");
        fgets(cmdline, MAXLINE, stdin);
        if (feof(stdin))
            exit(0);
        /* Evaluate */
        eval(cmdline);
    }
}
/* $end shellmain */

void mywait(pid_t pid)
{
    int i;
    for (i = 0; i < prcnt; i++)
    {
        if (prlist[i].pid == pid)
        {
            break;
        }
    }
    if (i == prcnt)
        return;
    while (prlist[i].status == 0 && prlist[i].pid == pid)
    {
        sleep(1);
    }
}

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline)
{
    char *argv[10][MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];       /* Holds modified command line */
    char cwd[1024];
    char cmd[10][100];
    int bg = 0, status; /* Should the job run in bg or fg? */

    pid_t pid; /* Process id */
    sigset_t mask, prev;
    Sigemptyset(&prev);
    Sigemptyset(&mask);
    Sigaddset(&mask, SIGINT);
    Sigaddset(&mask, SIGTSTP);

    char temp[MAXLINE];
    char *tempargv[MAXARGS];
    strcpy(temp, cmdline);
    parseline(temp, tempargv);

    if (tempargv[0] == NULL)
    {

        for (int i = 0; i < print_idx; i++)
        {
            printf("%s", ready_to_print[i]);
        }
        print_idx = 0;
        return; /* Ignore empty lines */
    }

    strcpy(buf, cmdline);
    char *ptr = strtok(buf, "|");
    int j = 0;
    for (int i = 0; ptr != NULL; i++)
    {
        strcpy(cmd[i], ptr);
        ptr = strtok(NULL, "|");
        j = i;
    }
    for (int i = 0; i <= j; i++)
    {
        while (cmd[i][0] == ' ')
            strcpy(cmd[i], cmd[i] + 1);
    }
    for (int i = 0; i <= j; i++)
    {
        bg += parseline(cmd[i], argv[i]);
    }

    //make pipe
    int *pipes;
    pipes = malloc(sizeof(int) * (j)*2);

    for (int i = 0; i < j; i++)
    {
        pipe(pipes + i * 2);
    }
    int builtin_flag = 0;

    pid_t pidlist[10];

    //fork child process
    for (int i = 0; i <= j; i++)
    {

        if (builtin_flag = !builtin_command(argv[i]))
        { //quit -> exit(0), & -> ignore, other -> run
            if (bg)
                Sigprocmask(SIG_BLOCK, &mask, &prev);
            if ((pidlist[i] = Fork()) == 0)
            { //child
                if (j == 0)
                { //no pipe
                    for (int t = 0; t < 2 * (j); t++)
                    {
                        close(pipes[t]);
                    }

                    execvp(argv[0][0], argv[0]);
                }
                else if (i == 0)
                { //first pipe
                    dup2(pipes[1], 1);

                    for (int t = 0; t < 2 * (j); t++)
                    {
                        close(pipes[t]);
                    }

                    execvp(argv[0][0], argv[0]);
                }
                else if (i == j)
                { //last pipe
                    dup2(pipes[i * 2 - 2], 0);

                    for (int t = 0; t < 2 * (j); t++)
                    {
                        close(pipes[t]);
                    }

                    execvp(argv[i][0], argv[i]);
                }
                else
                { //middle pipe
                    dup2(pipes[i * 2 - 2], 0);
                    dup2(pipes[i * 2 + 1], 1);

                    for (int t = 0; t < 2 * (j); t++)
                    {
                        close(pipes[t]);
                    }

                    execvp(argv[i][0], argv[i]);
                }
                exit(0);
            }
            if (bg)
                Sigprocmask(SIG_SETMASK, &prev, NULL);

            //push process to prlist
            prlist[prcnt].pid = pidlist[i];
            if (!bg)
                prlist[prcnt].status = 0;
            else
                prlist[prcnt].status = 1;
            prlist[prcnt].order = nextorder;
            strcpy(prlist[prcnt].cmdline, cmdline);
            if (i == j)
                prlist[prcnt++].printable = 1;
            else
                prlist[prcnt++].printable = 0;
            //prcnt++;
        }
    }
    if (builtin_flag == 0)
        return;
    nextorder++;

    for (int t = 0; t < 2 * (j); t++)
    {
        close(pipes[t]);
    }

    if (!bg)
    {
        for (int i = 0; i <= j; i++)
        {
            //waitpid(pidlist[i], &status, 0);
            //wait(&status);
            mywait(pidlist[i]);
            //delete_process(pid);
        }
    }
    else
    {
        printf("%d %s", pidlist[j], cmdline);
    }
    for (int i = 0; i < print_idx; i++)
    {
        printf("%s", ready_to_print[i]);
    }
    print_idx = 0;
    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv)
{
    char cwd[1024];
    if (!strcmp(argv[0], "exit"))
    { /* exit command */
        exit(0);
    }
    else if (!strcmp(argv[0], "cd"))
    {
        if (argv[1] == NULL)
        {
            chdir(environ[20] + 5);
        }
        else if (chdir(argv[1]) == -1)
        {
            if (!strcmp(argv[1], "~"))
            {
                chdir(environ[20] + 5);
            }
            else
                printf("invalid dir\n");
        }
        return 1;
    }
    else if (!strcmp(argv[0], "jobs"))
    {
        for (int i = 0; i < prcnt; i++)
        {
            if (prlist[i].printable == 1)
            {
                if (prlist[i].status == 1)
                {
                    printf("%d running %s", prlist[i].order, prlist[i].cmdline);
                }
                else if (prlist[i].status == 2)
                {
                    printf("%d stopped %s", prlist[i].order, prlist[i].cmdline);
                }
            }
        }
        return 1;
    }
    /*
    else if (!strcmp(argv[0], "kill")){
        if(argv[1][0] == '%')
            prlist[atoi(argv[1]+1)].status = -1;
    }
    */
    else if (!strcmp(argv[0], "&")) /* Ignore singleton & */
        return 1;
    else if (!strcmp(argv[0], "kill"))
    {
        if (argv[1][0] == '%')
        {
            strcpy(argv[1], argv[1] + 1);
            int now = atoi(argv[1]);
            int i = 0;
            for (i = 0; i < prcnt; i++)
            {
                if (prlist[i].order == now)
                {
                    if (prlist[i].printable)
                    {
                        sprintf(ready_to_print[print_idx++], "process %d is exited\n", now);
                    }
                    kill(prlist[i].pid, SIGKILL);
                    delete_process(i);
                    i -= 1;
                }
            }
            if (i == prcnt)
                return 1;
            return 1;
        }
        else
            return 0;
    }
    else if (!strcmp(argv[0], "bg"))
    {
        if (argv[1][0] == '%')
        {
            strcpy(argv[1], argv[1] + 1);
            int now = atoi(argv[1]);
            for (int i = 0; i < prcnt; i++)
            {
                if (prlist[i].order == now && prlist[i].status == 2)
                {
                    prlist[i].status = 1;
                    kill(prlist[i].pid, SIGCONT);
                    if (prlist[i].printable == 1)
                    {
                        printf("process %d restart\n", prlist[i].order);
                    }
                }
            }
            return 1;
        }
        else
            return 0;
    }
    else if (!strcmp(argv[0], "fg"))
    {
        if (argv[1][0] == '%')
        {
            strcpy(argv[1], argv[1] + 1);
            int now = atoi(argv[1]);
            pid_t pidlist[10];
            int j = 0;
            for (int i = 0; i < prcnt; i++)
            {
                if (prlist[i].order == now && prlist[i].status == 2)
                {
                    prlist[i].status = 0;
                    pidlist[j++] = prlist[i].pid;
                    kill(prlist[i].pid, SIGCONT);
                    if (prlist[i].printable == 1)
                    {
                        printf("process %d restart\n", prlist[i].order);
                    }
                }
            }
            for (int i = 0; i < j; i++)
            {
                mywait(pidlist[i]);
            }
            return 1;
        }
        else
            return 0;
    }
    else
        return 0; /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv)
{
    char *delim; /* Points to first space delimiter */
    int argc;    /* Number of args */
    int bg;      /* Background job? */

    buf[strlen(buf) - 1] = ' ';   /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
        buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' ')))
    {
        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;
        while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;

    if (argc == 0) /* Ignore blank line */
        return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc - 1] == '&')) != 0)
        argv[--argc] = NULL;

    if (argv[argc - 1][strlen(argv[argc - 1]) - 1] == '&')
    {
        bg = 1;
        argv[argc - 1][strlen(argv[argc - 1]) - 1] = '\0';
    }

    return bg;
}
/* $end parseline */

void sigchld_handler(int sig)
{

    int status;
    pid_t pid;
    while ((pid = waitpid(-1, &status, WNOHANG | WUNTRACED)) > 0)
    {
        int now = 0;
        for (now = 0; now < prcnt; now++)
        {
            if (prlist[now].pid == pid)
                break;
        }
        if (now == prcnt)
            break;
        //exit
        if (WIFEXITED(status))
        {

            delete_process(now);
        }
        //terminated by signal
        else if (WIFSIGNALED(status) && prlist[now].printable && prlist[now].status == 0)
        {
            sprintf(ready_to_print[print_idx++], "process %d is terminaed by signal!!\n", prlist[now].order);
            delete_process(now);
        }
        //suspended
        else if (WIFSTOPPED(status) && prlist[now].printable && prlist[now].status == 0)
        {
            sprintf(ready_to_print[print_idx++], "process %d is stopped by signal!!\n", prlist[now].order);
        }
        status = 0;
    }
}

void sigint_handler(int sig)
{
    pid_t pid = -1;
    pid_t pidlist[10];
    int j = 0;
    for (int i = 0; i < prcnt; i++)
    {
        if (prlist[i].status == 0)
        {
            pidlist[j++] = prlist[i].pid;
            prlist[i].status = -1;
        }
    }
    int flag;
    for (int i = 0; i < j; i++)
        flag = kill(pidlist[i], SIGINT);
    if (flag == -1 || j == 0)
    {
        //printf("\nCSE4100:P4-myshell> ");
        fflush(stdout);
    }
    return;
}

void sigtstp_handler(int sig)
{
    pid_t pid;
    pid_t pidlist[10];
    int j = 0;
    for (int i = 0; i < prcnt; i++)
    {
        if (prlist[i].status == 0)
        {
            pidlist[j++] = prlist[i].pid;
            prlist[i].status = 2;
        }
    }
    int flag;
    for (int i = 0; i < j; i++)
    {
        flag = kill(pidlist[i], SIGTSTP);
    }
    if (flag == 0)
    {
        //printf("\nCSE4100:P4-myshell> ");
        fflush(stdout);
    }
    return;
}

void delete_process(int now)
{

    for (int i = now; i < prcnt - 1; i++)
    {
        prlist[i].pid = prlist[i + 1].pid;
        prlist[i].status = prlist[i + 1].status;
        prlist[i].order = prlist[i + 1].order;
        strcpy(prlist[i].cmdline, prlist[i + 1].cmdline);
        prlist[i].printable = prlist[i + 1].printable;
    }
    prlist[prcnt - 1].status = -1;
    prlist[prcnt - 1].pid = -1;
    prlist[prcnt - 1].order = -1;
    prlist[prcnt - 1].printable = -1;
    prcnt--;
    nextorder = 1;
    for (int i = 0; i < prcnt; i++)
    {
        if (nextorder < prlist[i].order && prlist[i].status != -1 && prlist[i].printable == 1)
            nextorder = prlist[i].order + 1;
    }
    return;
}
