#include "20171598.h"

//start point if dump called
int dumppointer;
unsigned char memory[MEMORYSIZE];


void print_dump(int start, int end);
void reset();
void edit(int idx, int v);
void fill(int start, int end, int v);
