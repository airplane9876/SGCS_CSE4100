#include "20171598.h"

//var
typedef struct sym_node{
    char symbol[10];
    int address;
    struct sym_node* next;
}sym_node;

sym_node** symbol_table;


typedef struct object{
    int location_counter;
    char object_code[23];
    struct object* next;
}object;

object* object_list;
object* modi;


FILE* imp, *fp, *sp, *lp, *op;

//buffer : read asm file
//buffer2 : read immediate file
//word : tok buffer and buffer2
//obcode : object code
char program_name[10], buffer[100], word[4][100], buffer2[100], obcode[23];

int locctr, linenum, reg_num[26], reg_value[26], filesize, startaddress, recordlen;

//func
void pass1();
void print_symbol();
