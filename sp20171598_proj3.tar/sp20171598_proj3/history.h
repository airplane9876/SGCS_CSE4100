#include "20171598.h"

typedef struct history_node{
	int num;
	char command[MAXLEN];
	struct history_node* next;
}history_node;

history_node* history;


void his_add();
void his();
