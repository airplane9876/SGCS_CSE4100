#include "hash.h"
#include "history.h"//for use his_add()

//return hashvalue of char* a
int find_hashvalue(char* a){
	int alen = strlen(a);	
	int ret = 0, i = 0;
	for (i = 0; i < alen; i++){
		ret += a[i];
	}
	return ret%20;
}


//insert into hashtable
void push_hashtable(int idx, node* now){
	node* temp = hashTable[idx];
	if (temp == NULL)
		hashTable[idx] = now;
	else{
		while(temp->next != NULL)
			temp = temp->next;
		temp->next = now;
	}
}


//make hashtable
void make_hashtable(){
	hashTable = (node**)calloc(20, sizeof(node*));

	FILE *fp = fopen("opcode.txt", "r");
	if (fp == NULL) printf(" \"opcode.txt\" not exists\n");

	int nownum;
	char nowmnemonic[10];
	char temp[10];
	while(fscanf(fp, "%X %s %s", &nownum, nowmnemonic, temp) != EOF){
		node* now = malloc(sizeof(node));
		now->num = nownum;
		strcpy(now->mnemonic, nowmnemonic);
        strcpy(now->format, temp);
		now->next = NULL;
		nownum = find_hashvalue(nowmnemonic);
		push_hashtable(nownum, now);
	}
	fclose(fp);
	return;
}

//print hashtable
void print_hashtable(){
    for (int i = 0; i < 20; i++){
        printf("%d : ", i);
        node* temp = hashTable[i];

        while(temp != NULL){
            printf("[%s,%02X] ", temp->mnemonic, temp->num);
            if (temp->next != NULL)
                printf("-> ");
            temp = temp->next;
        }
        printf("\n");
    }
}

//process opcode mnemonic command
void find_mnemonic(char* to_find){
    int hashnum = find_hashvalue(to_find);
    
    //if to_find has ',' 
    //that mean wrong command syntax;
    int to_find_len = strlen(to_find);
    for (int i = 0; i < to_find_len; i++){
        if (to_find[i] == ','){
            printf("invalid command\n");
            return;
        }
    }

    //if command is valid, find to_find at hashTable
    node* temp = hashTable[hashnum];

    while(temp != NULL){
        if (strcmp(temp->mnemonic, to_find)==0){
            printf("opcode is %02X\n", temp->num);
            strcpy(par_for_history[0], to_find);
            his_add(); 
            return;
        }
        temp = temp->next;
    }


    printf("input mnemonic is not exist\n");
}

//get mnemonic's format
int find_mnemonic_format(char* to_find){

    int hashnum = find_hashvalue(to_find);
    
    //if to_find has ',' 
    //that mean wrong command syntax;
    int to_find_len = strlen(to_find);
    for (int i = 0; i < to_find_len; i++){
        if (to_find[i] == ','){            
            return -1;
        }
    }

    //if command is valid, find to_find at hashTable
    node* temp = hashTable[hashnum];

    while(temp != NULL){
        if (strcmp(temp->mnemonic, to_find)==0){
            if (strcmp(temp->format, "1")==0) return 1;
            if (strcmp(temp->format, "2")==0) return 2;
            if (strcmp(temp->format, "3/4")==0) return 3;
        }
        temp = temp->next;
    }

    return -1;


}

//
int find_mnemonic_opcode(char* to_find){
    
    int hashnum = find_hashvalue(to_find);
    
    //if to_find has ',' 
    //that mean wrong command syntax;
    int to_find_len = strlen(to_find);
    for (int i = 0; i < to_find_len; i++){
        if (to_find[i] == ','){            
            return -1;
        }
    }

    //if command is valid, find to_find at hashTable
    node* temp = hashTable[hashnum];

    while(temp != NULL){
        if (strcmp(temp->mnemonic, to_find)==0){
            return temp->num;
        }
        temp = temp->next;
    }
    return -1;
}


int find_opcode_mnemonic(int opcode){
    
    for (int i= 0; i < 26; i++){
        node* temp = hashTable[i];
        while(temp != NULL){
            if (temp->num == opcode){
                if (strcmp(temp->format, "1")==0) return 1;
                else if (strcmp(temp->format, "2")==0) return 2;
                else return 3;
            }
            temp = temp->next;
        }
    }
    return -1;
}


