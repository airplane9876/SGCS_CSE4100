#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

#define LINUX
#ifdef LINUX
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#endif


#define MEMORYSIZE 1048576
#define MAXLEN 100
//var
bool quitflag;

char command_for_history[MAXLEN], par_for_history[3][MAXLEN];
char command[MAXLEN], par[3][MAXLEN], trash[3][MAXLEN];
char* ptr;

int parnum;
//func

//void make_input_lower(int flag, char* a);
