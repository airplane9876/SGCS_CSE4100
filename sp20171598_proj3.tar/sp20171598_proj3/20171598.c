#include "20171598.h"
#include "hash.h"
#include "history.h"
#include "memory.h"
#include "assemble.h"
#include "linker.h"


//make char* a to lower
//not use because only command with lower will be valid
/*
void make_input_lower(int flag, char* a){
    int alen = strlen(a);
    for (int i = 0; i < alen; i++){
        if (flag == -1)
            command_for_history[i] = tolower(a[i]);
    }
}
*/

//print file contents
void type(){
    FILE* fp;
    //if file is not exists
    if ( (fp = fopen(par[0], "r")) == NULL){
        printf("invalid filename\n");
        return;
    }
    //add history
    strcpy(par_for_history[0], par[0]);
    his_add();
   
    //read file
    char buffer[200];
    while(fgets(buffer, 200, fp)!=NULL){
        printf("%s", buffer);
    }


    fclose(fp);
}




int min(int a, int b){
    if (a < b) return a;
    else return b;
}


//print members of cur dir
void dir(){

	//dir pointer
	DIR* dp = NULL;

	//dir entry pointer
	//char* d_name == file name
	struct dirent* entry = NULL;
	
	//file info
	//mode_t st_mode == entry's form
	struct stat buf;

	//open cur dir
	if ( (dp = opendir("./")) == NULL){
		printf("can not open dir\n");
	}
	
	int enter = 0;
	//loop members of cur dir
	while( (entry=readdir(dp)) != NULL){
		lstat(entry->d_name, &buf);
		if (S_ISDIR(buf.st_mode))
			printf("%19s/", entry->d_name);
		else if (S_ISREG(buf.st_mode))
			printf("%19s*", entry->d_name);
		else
			printf("%20s\t", entry->d_name);
		enter++;
		if (enter % 4 == 0){
			printf("\n");
		}
	}
	
	closedir(dp);
	printf("\n");
}//void dif() end


//exit program
void quit(){
    quitflag = 1;

    //free hashTable
    node* prev, *now;
    for (int i = 0; i < 20; i++){
        prev = hashTable[i];
        while(prev != NULL){
            now = prev->next;
            free(prev);
            prev = now;
        }
    }

    //free history list
    history_node* p, *n;
    p = history;
    while(p != NULL){
        n = p->next;
        free(p);
        p = n;
    }

    //free symbol table
    sym_node* a, *b;
    for (int i = 0; i < 26; i++){
        a = symbol_table[i];
        while(a != NULL){
            b = a->next;
            free(a);
            a = b;
        }
    }

    est_node* x, *y;
    for (int i = 0; i < 26; i++){
        x = estab[i];
        while(x != NULL){
            y = x->next;
            free(y);
            x = y;
        }
    }

    //remove useless file
    remove("immediate");
    remove("symbol");

}//void quit() end



//check command whether it has another parameter
//return 0 : no  1 : yes
bool check_parameter(){
    ptr = strtok(NULL, " \n\t");
    if (ptr == NULL) return 0;
    else return 1;
}//bool check_parameter() end



//check parameter has valid value
bool check_value(int i){
    char temp[100]; int t;
    int flag = sscanf(par[i], "%x %s", &t, temp);
    if (flag>=2) flag =0;
    
    //if parameter has valid value, convert string to Hex
    if (flag==1){
        sprintf(par_for_history[i], "%X", t);
    }
    return flag;
}//return 1 : valid parameter


//store parameters
void parameter_parsing(int* parnum){
        if (ptr[0] == ' ' || ptr[0] == '\t' || ptr[0] == '\n'){
            *parnum = sscanf(ptr, "%[ \t] %[^,\n] %[,] \
                %[^,\n] %[,] %[^\n]",trash[2], par[0],\
                trash[0], par[1], trash[1], par[2]);
            *parnum = *parnum-1;
        }
        else{
            *parnum = sscanf(ptr, "%[^,\n] %[,] \
                %[^,\n] %[,] %[^\n]", par[0],\
                trash[0], par[1], trash[1], par[2]);
        }
}



//process input
void input(){
	printf("sicsim> ");

    //init
    memset(command, 0, MAXLEN);
    memset(command_for_history, 0, MAXLEN);
    memset(par, 0, 3*MAXLEN);
    memset(trash, 0, 3*MAXLEN);
    parnum = 0;

	//store input
	fgets(command, sizeof(command), stdin);
    
    //select main command
	ptr = strtok(command, " \n\t");
    
    //check if command doesn't input
    if (ptr == NULL){
        printf("invalid command\n");
        return;
    }
    
    strcpy( command_for_history, ptr);


	//check main command which don't need parameter
	if (strcmp(command_for_history, "q") == 0 || strcmp(command_for_history, "quit") == 0){
        printf(">>>>>");
        if (check_parameter()){
		    printf("invalid command\n");
            return;
        }
        else{
	        quit();
            return;
        }
	}//quit command end
    else if (strcmp(command_for_history, "help")==0 || strcmp(command_for_history, "h")==0){
        if (check_parameter()){
		    printf("invalid command\n");
            return;
        }
        else{
            his_add();
            printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n", "h[elp]", \
                    "d[ir]",\
                    "q[uit]",\
                    "hi[story]",\
                    "du[mp] [start, end]",\
                    "e[dit] address, value",\
                    "f[ill] start, end, value",\
                    "reset",\
                    "opcode mnemonic",\
                    "opcodelist",\
                    "assemble filename",\
                    "type filename",\
                    "symbol",\
                    "progaddr",\
                    "loader",\
                    "bp",\
                    "run"\
            );
            return;
        }
	}//strcmp ptr==help end
	else if ((strcmp(command_for_history, "d") == 0) || (strcmp(command_for_history, "dir") == 0)){
        if (check_parameter()){
		    printf("invalid command\n");
            return;
        }
        else{
            his_add();
	    	dir();
            return;
        }
	}//dir command end
	else if ((strcmp(command_for_history, "hi") == 0) || (strcmp(command_for_history, "history") == 0)){
        if (check_parameter()){
		    printf("invalid command\n");
            return;
        }
        else{
            his_add();
	    	his();
            return;
        }
	}//history command end
    else if(strcmp(command_for_history, "opcodelist") == 0){
        if (check_parameter()){
		    printf("invalid command\n");
            return;
        }
        else{
            his_add();
            print_hashtable();
            return;
        }
    }//opcodelist command end
    else if (strcmp(command_for_history, "reset") == 0){
        if (check_parameter()){
            printf("invalid command\n");
            return;
        }
        else{
            his_add();
            reset();
            return;
        }
    }//reset command end
    else if (strcmp(command_for_history, "symbol")==0){
        if (check_parameter()){
            printf("invalid command\n");
            return;
        }
        else{
            print_symbol();
            return;
        }
    }//symbol command end
    else if (strcmp(command_for_history, "run")==0){
        if (check_parameter()){
            printf("invalid command\n");
            return;
        }
        else{
            run();
            return;
        }
    }//run command end
    //end handle command which don't need parameter

    //now handle command which need parameter 1
    else if (strcmp(command_for_history, "opcode") == 0){
        ptr = strtok(NULL, " \n\t");

        //if command don't have parameter
        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }

        parameter_parsing(&parnum);
        if (parnum == 1){
            find_mnemonic(par[0]);
            return;
        }
        else{
            printf("invalid command\n");
            return;
        }
    }//opcode command end
    //end handle command which need parameter 1

    //now handle command which need many parameter
    else if ((strcmp(command_for_history, "type") == 0)){
        ptr = strtok(NULL, "\n");
        //if command has no parameter
        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }


        parameter_parsing(&parnum);

        //if command has only one parameter
        if (parnum == 1){
            strcpy(par_for_history[0], par[0]);
            type();
            return;
        }
        else{
            printf("invalid command\n");
            return;
        }
    }//type command end
    
    else if ((strcmp(command_for_history, "progaddr") == 0)){
        ptr = strtok(NULL, "\n");
        //if command has no parameter
        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }

        parameter_parsing(&parnum);

        //if command hans only one parameter
        if (parnum == 1 && check_value(0)){
            if (strtol(par[0], NULL, 16) >= 0 && strtol(par[0], NULL, 16) < 0x100000){
                strcpy(par_for_history[0], par[0]);
                progaddr = strtol(par[0], NULL, 16);
                his_add();
            }
            else
                printf("out of range\n");
            return;
        }
        else{
            printf("invalid command\n");
            return;
        }
    }//progaddr command end

    else if ((strcmp(command_for_history, "du") == 0) || (strcmp(command_for_history, "dump") == 0) ){
        ptr = strtok(NULL, "\n");
        //if command is du or dump
        if (ptr == NULL){
            print_dump(dumppointer, min(0xFFFFF, dumppointer+159));
            dumppointer = (dumppointer + 160) % MEMORYSIZE;
            return;
        }

        //if command has parameter
        parameter_parsing(&parnum);

        //if command is dump
        if (parnum == 0){
            int strl = strlen(ptr);
            for (int i = 0; i < strl; i++){
                if(ptr[i] != ' ' && ptr[i] != '\t' && ptr[i] != '\n') {
                    printf("invalid command\n");
                    return;
                }
            }
            print_dump(dumppointer, min(0xFFFFF, dumppointer+159));
            dumppointer = (dumppointer + 160) % MEMORYSIZE;
            return;
        }
        //if dump has only one parameter
        if (parnum == 1){
            if (check_value(0)){
                print_dump(strtol(par[0], NULL, 16), min(0xFFFFF, strtol(par[0], NULL, 16)+159));
                return;
            }
            else{
                printf("invalid command\n");
                return;
            }
        }
        //if dump has two parameter
        if (parnum == 3){
            if ( (strlen(trash[0]) == 1) && check_value(0) && check_value(1) ){
                print_dump(strtol(par[0], NULL, 16), min(0xFFFFF, strtol(par[1], NULL, 16)));
                return;
            }
            else{
                printf("invalid command\n");
                return;
            }
        }
        else{
            printf("invalid command\n");
            return;
        }
    }  //end dump command    

    else if ( (strcmp(command_for_history, "e")==0) || (strcmp(command_for_history, "edit") == 0 ) ){
        ptr = strtok(NULL, "\n");

        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }

        //if command has parameter
        parameter_parsing(&parnum);

        //if command has valid parmeter cnt
        if (parnum == 3){
            
            //if parameter has valid form
            if (strlen(trash[0]) == 1 && check_value(0) && check_value(1)){
                edit(strtol(par[0], NULL, 16), strtol(par[1], NULL, 16));
                return;
            }
            else{
                printf("invalid command\n");
                return;
            }

        }
        else{
            printf("invalid command\n");
            return;
        }        
    }//end edit command  
    if ( (strcmp(command_for_history, "f") == 0) || ( strcmp(command_for_history, "fill") == 0) ){
        ptr = strtok(NULL, "\n");

        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }

        //if command has parameter
        parameter_parsing(&parnum);
        
        //if command has valid parameter cnt
        if (parnum == 5){

            //if parameter has valid form
            if ( (strlen(trash[0]) == 1) && (strlen(trash[1]) == 1) && check_value(0) && \
                    check_value(1) && check_value(2) ){
                fill(strtol(par[0], NULL, 16), strtol(par[1], NULL, 16), strtol(par[2], NULL, 16));
                return;
            }
            else {
                printf("invalid command\n");
                return;
            }
        }
        else{
            printf("invalid command\n");
            return;
        }
    }//end fill command

    else if (strcmp(command_for_history, "assemble") == 0){
        ptr = strtok(NULL, "\n");

        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }

        parameter_parsing(&parnum);

        if (parnum == 1){
            strcpy(par_for_history[0], par[0]);
            pass1();
        }
        else{
            printf("invalid command\n");
            return;
        }
    }//end assemble command

    else if (strcmp(command_for_history, "loader")==0){
        ptr = strtok(NULL, "\n");

        if (ptr == NULL){
            printf("invalid command\n");
            return;
        }
        //file count check
        int flag = sscanf(ptr,"%s %s %s %s", par[0], par[1], par[2], trash[0]);
        if (flag > 3 || flag == 0) {
            printf("invalid command\n");
            return;
        }

        for (int i = 0; i < flag; i++){
            char p[100];
            strcpy(p, par[i]+strlen(par[i])-4);

            //file name check
            if (strcmp(p, ".obj")!=0){
                printf("invalid command\n");
                return;
            }
            strcpy(par_for_history[i], par[i]);
            parnum += 2;
        }
        linkerflag= 1;
        linker(flag);
    }//end loader command

    else if (strcmp(command_for_history, "bp")==0){
        ptr = strtok(NULL, "\n");

        if (ptr == NULL){
            printf("\t\tbreakpoint\n");
            printf("\t\t----------\n");
            for (int i = 0; i < bpcnt; i++){
                printf("\t\t%X\n", bp[i]);
            }
            his_add();
            return;
        }

        parameter_parsing(&parnum);

        if (parnum == 1){
            
            if (strcmp(par[0], "clear")==0){
                strcpy(par_for_history[0], par[0]);
                for (int i = 0; i < bpcnt; i++) bp[i] = -1;
                bpcnt = 0;
                printf("\t\t[\033[0;32mok\033[0;97m] clear all breakpoints\n");
                his_add();
            }
            else if (check_value(0)){
                strcpy(par_for_history[0], par[0]);
                bp[bpcnt++] = strtol(par[0], NULL, 16);
                printf("\t\t[\033[0;32mok\033[0;97m] create breakpoint %s\n", par[0]);
                his_add();
            }
            else{
                printf("invalid command\n");
            }
        }

        else{
            printf("invalid command\n");
        }

    }//end bp command
	else{
		printf("command not supported\n");
	}
}//input() end

//init register inform
void reg_init(){
    for (int i = 0; i < 26; i++){
        reg_num[i]=-1;
    }
    reg_num['A'-65] = 0;
    reg_num['X'-65] = 1;
    reg_num['L'-65] = 2;
    reg_num['B'-65] = 3;
    reg_num['S'-65] = 4;
    reg_num['T'-65] = 5;
    reg_num['F'-65] = 6;
    reg_num['P'-65-1] = 8;
    reg_num['S'-65-1] = 9;
}

//init for start program
void init(){
	quitflag = 0;
    dumppointer = 0;
    history = NULL;	
	make_hashtable();
    symbol_table = (sym_node**)calloc(26, sizeof(sym_node*));
    estab = (est_node**)calloc(26, sizeof(est_node*));
    reg_init();
    parnum = 0;
    progaddr = 0;
    bpcnt = 0;
    for (int i = 0; i < 1000; i++){
        bp[i] = -1;
    }
}


int main(){
	init();
    while(!quitflag){
		input();
	}
	return 0;
}
