#include "assemble.h"
#include "hash.h"
#include "history.h"

//free symbol table
void free_symtable(){
    if (symbol_table == NULL) return;

    sym_node* temp, *prev;

    for (int i = 0; i < 26; i++){
        temp = symbol_table[i];
        prev = temp;
        while(prev != NULL){
            temp = prev->next;
            free(prev);
            prev = temp;
        }
        symbol_table[i] = NULL;
    }

    symbol_table = (sym_node**)calloc(26, sizeof(sym_node*));
}//free symbol table end

//print modification record and free modification linked list
void print_modi_code(){
    if (modi == NULL) return;

    object* now = modi;
    object* prev;

    //print modification record
    while(now != NULL){
        fprintf(op, "M%06X05\n", now->location_counter+1);
        now = now->next;
    }

    //free linked list
    prev = modi;
    while(prev != NULL){
        now = prev->next;
        free(prev);
        prev = now;
    }
    modi = NULL;
}//end print and free modification record

//print and free text record
void print_object_code(){
    if (object_list == NULL) return;

    object* now = object_list;
    object* prev;

    //print text record
    fprintf(op, "%02X", recordlen/2);
    recordlen = 0;
    while(now != NULL){
        fprintf(op, "%s", now->object_code);
        now = now->next;
    }
    fprintf(op, "\n");

    //free text record linked list
    prev = object_list;
    while(prev != NULL){
        now = prev->next;
        free(prev);
        prev = now;
    }
    object_list = NULL;
}//end print and free text record


//stop assemble 
void assemble_fail(int i){

    //print error line
    printf("%s", buffer);

    //print reason
    switch (i){
        case 0:printf("not exist opcode\n"); break;
        case 1:printf("not valid line\n"); break;
        case 2:printf("base register not setted\n");break;
        case 4:printf("out of range\n");break;
        case 5:printf("invalid symbol\n");break;
        case 6:printf("invalid filename\n");break;
        case 7:printf("symbol name overlap\n");break;
        case 8:printf("use mnemonic as symbol\n");
    }

    //free and remove uselss data
    remove("immediate");  
    fclose(imp);
    fclose(fp);
    print_modi_code();
    print_object_code();
    if(op != NULL){
        fclose(op);
        op = NULL;
        char* p = strtok(par[0], ".");
        strcat(p, ".obj");
        remove(p);
    }
    if(lp != NULL){
        char* p = strtok(par[0], ".");
        strcat(p, ".lst");
        remove(p);
        fclose(lp);
        lp = NULL;
    }
    free_symtable();

    return;
}//end stop assemble

//push modification record to linked list
void push_modi(int locctr, long long oc){

    //make node
    object* now = calloc(1, sizeof(object));
    now->location_counter = locctr;
    char t[23];
    sprintf(t, "%08llX", oc);
    strcpy(now->object_code, t);
    now->next = NULL;

    //push node
    object* temp = modi;
    if (modi == NULL){
        modi = now;
    }
    else{
        while(temp->next != NULL){
            temp = temp->next;
        }
        temp->next = now;
    }
}//end push_modi


//push symbol to symbol table
//0 : fail   1 : success
bool push_symtable(char* to_push, int address){

    if (find_mnemonic_opcode(to_push) != -1){
        assemble_fail(8);
        return 0;
    }
    if (strcmp(to_push, "START")==0 || strcmp(to_push, "END")==0 || strcmp(to_push, "RESW")==0 || \
            strcmp(to_push, "RESB")==0 || strcmp(to_push, "BYTE")==0 || strcmp(to_push, "WORD")==0 || \
            strcmp(to_push, "BASE")==0 || strcmp(to_push, "NOBASE")==0){
        assemble_fail(8);
        return 0;
    }

    //make node
    sym_node* now = calloc(1,sizeof(sym_node));
    strcpy(now->symbol, to_push);
    now->address = address;

    //find hash value to push
    int idx = to_push[0]-65;
    if (idx < 0 || idx >= 26){
        assemble_fail(5);
        return 0;
    }

    //push node asc
    sym_node* temp = symbol_table[idx];

    if (temp == NULL){
        symbol_table[idx] = now;
    }
    else{
        if (strcmp(temp->symbol, now->symbol)>0){
            now->next = temp;
            symbol_table[idx] = now;
            return 1;
        }
        if (strcmp(temp->symbol, now->symbol)==0){
            assemble_fail(7);
            return 0;
        }
        
        while(temp->next != NULL && strcmp(temp->next->symbol, now->symbol)<0) temp = temp->next;

        if (temp->next != NULL && strcmp(temp->next->symbol, now->symbol)==0){
            assemble_fail(7);
            return 0;
        }
        now->next = temp->next;
        temp->next = now;
    }
    return 1;
}//end push_symtable


//write on immediate file
void imp_write(int linenum, int locctr, char* w1){
    fprintf(imp, "%-6d %04X     %-10s", linenum, locctr, w1);
}


//push object code to linked list
void push_object_list(int locctr, char* oc){

    //if length > text record's max length
    if (recordlen + strlen(oc) > 60){
        //print text record line and free
        print_object_code();
        recordlen = 0;        
    }
    

    //make node
    object* now = calloc(1, sizeof(object));    
    now->location_counter = locctr;
    strcpy(now->object_code, oc);
    now->next = NULL;

    //push node    
    object* temp = object_list;
    if (object_list == NULL){
        object_list = now;
        fprintf(op, "T%06X", locctr);
    }
    else{
        while(temp->next != NULL){
            temp = temp->next;
        }
        temp->next = now;
    }

    recordlen += strlen(oc);

}//end push_object_list


//write lst file
void lp_write(int linenum, int locctr, char* w1, long long oc, int flag){
    w1[strlen(w1)-1] = '\0';
    if (flag == 0){
        fprintf(lp, "%-35s\t %llX\n", w1, oc);
        sprintf(obcode, "%llX", oc);
    }
    else if (flag == 1){
        fprintf(lp, "%-35s\t %llX\n", w1, oc);
        sprintf(obcode, "%llX", oc);
    }
    else if (flag == 2){
        fprintf(lp, "%-35s\t %04llX\n", w1, oc);
        sprintf(obcode, "%04llX", oc);
    }
    else if (flag == 3){
        fprintf(lp, "%-35s\t %06llX\n", w1, oc);
        sprintf(obcode, "%06llX", oc);
    }
    else if (flag == 4){
        fprintf(lp, "%-35s\t %08llX\n", w1, oc);
        sprintf(obcode, "%08llX", oc);
    }
    
    //for ready to write object file
    push_object_list(locctr, obcode);
    
}//end lp_write


//if command == symbol
void print_symbol(){
    his_add();

    bool flag = 1; 
    sp = fopen("symbol", "r");

    //if file not exist
    if (sp == NULL){
        printf("symbol table not exists\n");
        return;
    }

    //print symbol
    char symbol[100];
    int address;
    while( fgets(buffer, 100,sp) != NULL){
        flag = 0;
        sscanf(buffer, "%s %04X", symbol, &address);
        printf("\t%s\t%04X\n", symbol, address);
    }

    //if symbol not exist
    if (flag){
        printf("symbol table not exists\n");
        return;
    }

}//end print_symbol

//find symbol location
int find_symbol_loc(char* to_find){

    //check symbol has valid name
    if (to_find[0] < 65 || to_find[0] > 65+25) return -1;

    //find symbol location
    sym_node* temp = symbol_table[to_find[0]-65];
    while(temp != NULL){
        if (strcmp(temp->symbol, to_find)==0){
            return temp->address;
        }
        temp = temp->next;
    }
    return -1;
}//end find_symbol_loc

//store symbol if assembled success
void store_symbol(){
    sp = fopen("symbol", "w");
    sym_node* temp;
    for (int i =0; i < 26; i++){
        temp = symbol_table[i];
        while(temp != NULL){
            fprintf(sp, "%s %X\n", temp->symbol, temp->address);
            temp = temp->next;
        }
    }
    fclose(sp);
    sp = NULL;
}//end store_symbol


//pass 2
void pass2(){

    //file open
    fp = fopen(par[0], "r");
    imp = fopen("immediate", "r");
    char* p = strtok(par[0], ".");
    strcat(p, ".lst");
    lp = fopen(p, "w");
    p = strtok(par[0], ".");
    strcat(p, ".obj");
    op = fopen(p, "w");
    //file open end


    //program counter
    int pc;


    //buffer2 : immediate file, buffer : original file
    while( fgets(buffer2, 100, imp) != NULL){

        while( fgets(buffer, 100, fp) ){
            if (strcmp(buffer, "\n") == 0) continue;
            else break;
        }

        //continue comment line
        if (buffer[0] == '.') {
            fprintf(lp, "%s", buffer2);
            continue;
        }


        memset(word, 0, 400);
        
        //if line has no symbol
        if (buffer[0] == ' ' || buffer[0] == '\t'){
            sscanf(buffer2, "%d %x", &linenum, &locctr);
            sscanf(buffer, "%s %s %s", word[1], word[2], word[3]);
        }
        //if line has symbol
        else{    
            sscanf(buffer2, "%d %x", &linenum, &locctr);
            sscanf(buffer, "%s %s %s %s", word[0], word[1], word[2], word[3]);
        }

        //check 4 format
        int formatflag = 0;
        if (word[1][0] == '+'){
            formatflag = 1;
            strcpy(word[1], word[1]+1);
        }


        int instruction_size = find_mnemonic_format(word[1]);
       


        //BYTE, WORD, RESW, RESB,    START BASE END NOBASE
        if (instruction_size == -1){
            //BYTE
            if (strcmp(word[1], "BYTE")==0){
                if(strcmp(word[3],"\0")!=0){
                    assemble_fail(1);
                    return;
                }
                char* ptr = strtok(word[2], "/'");
                long long temp=0;
                if (strcmp(ptr, "X")==0){
                    ptr = strtok(NULL, "/'");
                    buffer2[strlen(buffer2)-1] = '\0';
                    fprintf(lp, "%-35s\t %s\n", buffer2, ptr);
                    push_object_list(locctr, ptr);
                    continue;
                }
                else if (strcmp(ptr, "C") == 0){
                    ptr = strtok(NULL, "/'");
                    int ptrlen = strlen(ptr);
                    for (int i = 0; i < ptrlen; i++, temp*=16*16){
                        temp += ptr[i];
                    }
                    temp /= 16*16;
                    lp_write(linenum, locctr, buffer2, temp, 0);
                    continue;
                }
                else{
                    assemble_fail(1);
                    return;
                }
            }
            //WORD
            else if (strcmp(word[1], "WORD")==0){
                int temp;
                sscanf(word[2], "%d", &temp);
                lp_write(linenum, locctr,buffer2, temp,1);
                continue;
            }
            //START
            else if (strcmp(word[1], "START")==0){
                fprintf(lp, "%s", buffer2);
                int len;
                sscanf(word[2], "%X", &len);
                fprintf(op, "H%-6s%06X%06X\n", word[0], len, filesize);
                continue;
            }
            //BASE
            else if (strcmp(word[1], "BASE")==0){
                //immediate mode
                if (word[2][0] == '#'){
                    strcpy(word[2], word[2]+1);
                }

                int symloc = find_symbol_loc(word[2]);
                if (symloc == -1){
                    int temp;
                    char trash[10];
                    sscanf(word[2], "%d %s", &temp, trash);
                    if (trash != NULL){
                        assemble_fail(1);
                        return;
                    }
                    reg_value['B'-65] = temp;
                }
                else{
                    reg_value['B'-65] = symloc;
                }
                fprintf(lp, "%s", buffer2);
                continue;
            }
            //NOBASE
            else if (strcmp(word[1], "NOBASE")==0){
                if (strcmp(word[2], "\0")){
                    assemble_fail(1);
                    return;
                }
                reg_value['B'-65] = -1;
                continue;
            }
            //END
            else if (strcmp(word[1], "END")==0){
                fprintf(lp, "%s", buffer2);
                continue;
            }
            //RES
            else if (strcmp(word[1], "RESW")==0 || strcmp(word[1], "RESB")==0) {
                //to much parameter
                if (strcmp(word[3], "\0")){
                    assemble_fail(1);
                    return;
                }

                //check parameter is int
                int a; char b[10];
                sscanf(word[2], "%d %s", &a, b);
                if (strcmp(b, "\0")){
                    assemble_fail(1);
                    return;
                }
                fprintf(lp, "%s", buffer2);
                print_object_code();
                continue;
            }
            else{
                assemble_fail(1);
                return;
            }
        }

        //format 1
        else if (instruction_size == 1){
            if (word[2] != NULL){
                assemble_fail(1);
                return;
            }
            lp_write(linenum, locctr, buffer2, find_mnemonic_opcode(word[1]), 1);
            continue;
        }
        
        //format 2
        else if (instruction_size == 2){
            //oc = object code
            int oc = 0;
            oc += find_mnemonic_opcode(word[1]);
            
            int regflag = 0;
            //invalid syntax
            if (strlen(word[2]) > 1 && word[2][1] != ',' && strcmp(word[2], "PC") && strcmp(word[2], "SW")){
               assemble_fail(1);
               return;
            }     

            if (strcmp(word[2],"\0")==0){
               assemble_fail(1);
               return;
            }

            if (strcmp(word[2],"PC")==0 || strcmp(word[2],"SW")==0){
                regflag = 1;
                word[2][0] -= 1;
            }
            //for delete ','
            strncpy(word[2], word[2], 1);

            //invalid register name
            if (word[2][0] < 65 || word[2][0] > 65+25 || (reg_num[word[2][0]-65]==-1 && regflag ==0)){
                assemble_fail(1);
                return;
            }


            oc *= 16;
            oc += reg_num[word[2][0]-65];
            
            regflag = 0;

            //invalid syntax
            if (strcmp(word[3], "\0")==0 && strcmp(word[1], "CLEAR") && strcmp(word[1], "SVC") && strcmp(word[1], "TIXR")){
                assemble_fail(1);
                return;
            }
            if (strcmp(word[3], "\0")!=0){
                if(strcmp(word[1], "CLEAR")==0 || strcmp(word[1], "SVC")==0 || strcmp(word[2], "TIXR")==0){
                    assemble_fail(1);
                    return;
                }


                if (strlen(word[3]) > 1 && strcmp(word[3], "PC") && strcmp(word[3], "SW")){
                    assemble_fail(1);
                    return;
                }
                if (strcmp(word[3], "PC")==0 || strcmp(word[3], "SW")==0){
                    regflag = 1;
                    word[3][0]-=1;
                }
                strncpy(word[3], word[3], 1);
                if (word[3][0] < 65 || word[3][0] > 65+25 || (reg_num[word[3][0]-65] == -1 && regflag == 0)){
                    assemble_fail(1);
                    return;
                }

                //valid syntax
                oc *= 16;
                oc += reg_num[word[3][0]-65];
            }
            //valid syntax
            else
                oc *= 16;


            lp_write(linenum, locctr, buffer2, oc, 2);
            continue;
        }//format 2

        //format 3
        else if (instruction_size + formatflag == 3){


            //add opcode at object code
            long long oc = 0;
            oc += find_mnemonic_opcode(word[1]);

            //move program counter
            pc = locctr + instruction_size+formatflag;

            //RSUB
            if (strcmp(word[1], "RSUB")==0){
                if (strcmp(word[2], "\0")==0){

                    oc += 3;
                    oc *= pow(16, 4);
                    lp_write(linenum, locctr, buffer2, oc, 3);

                    continue;
                }
                else{
                    assemble_fail(1);
                    return;
                }
            }


            if (word[2][0] == '#'){
                //immediate addressing. 
                oc += 1;
                strcpy(word[2], word[2]+1);
                int symloc = find_symbol_loc(word[2]);

                //not exist symbol
                if (symloc == -1){
                    int im;
                    char trash[100];
                    sscanf(word[2], "%d %s", &im, trash);
                    //invalid syntax
                    if (strcmp(trash, "\0")!=0){
                        assemble_fail(1);
                        return;
                    }
                    //if not symbol but int
                    oc*=pow(16,4);
                    oc += im;
                }

                //exist symbol
                else{
                    //pc relative
                    oc *= 16;
                    oc += 2;
                    oc *= pow(16,3);
                    oc += symloc-pc;
                }
                lp_write(linenum, locctr, buffer2, oc,3);
                continue;
            }//if word[2][0] == '#' end

            else{

                if(word[2][0] == '@'){
                    //indirect addressing
                    oc += 2;
                    strcpy(word[2], word[2]+1);
                }
                else{
                    oc += 3;
                }
                
                //if has index, remove ','
                if (strcmp(word[3], "\0")!=0){
                    word[2][strlen(word[2])-1] ='\0';
                }

                int symloc = find_symbol_loc(word[2]);
                
                //if symbol not exist
                if (symloc == -1){
                    assemble_fail(1);
                    return;
                }

                //if symbol exist
                else{

                    //identify indexing mode
                    if (strcmp(word[3], "\0")!=0){

                        //invalid syntax
                        if (strlen(word[3])>1){
                            assemble_fail(1);
                            return;
                        }
                        if (reg_num[word[3][0]-65]<0){
                            assemble_fail(1);
                            return;
                        }

                        oc *= 16;
                        oc += 8;
                    }

                    //identify relative mode
                    if (symloc - pc > 2047 || symloc - pc < -2048){
                        //base relative mode

                        //if not set base register
                        if (reg_value['B'-65] < 0){
                            assemble_fail(2);
                            return;
                        }  

                        //B - pc out of range
                        if (symloc - reg_value['B'-65]>4095 || symloc - reg_value['B'-65]<0){
                            assemble_fail(4);
                            return;
                        }

                        if (strcmp(word[3], "\0")==0)
                            oc *= 16;
                        oc += 4;
                         
                        oc *= pow(16,3);
                        oc += symloc - reg_value['B'-65];
            
                    }
                    else{
                        //pc relative mode
                        if (strcmp(word[3],"\0")==0)
                            oc *= 16;
                        oc += 2;
                        oc *= pow(16, 3);
                        if (symloc - pc < 0){
                            oc += pow(16,3)+(symloc-pc);
                        }
                        else
                            oc += symloc - pc;
                    }

                }
                lp_write(linenum, locctr, buffer2, oc,3);
                continue;
            }

        }//format 3 end

        //format 4
        else if (instruction_size + formatflag == 4){
            
            //add opcode at object code
            long long oc = 0;
            oc += find_mnemonic_opcode(word[1]);
            
            if (word[2][0] == '#'){
                //immediate addressing. 
                oc += 1;
                strcpy(word[2], word[2]+1);
                int symloc = find_symbol_loc(word[2]);

                //not exist symbol
                if (symloc == -1){
                    int im;
                    char trash[100];
                    sscanf(word[2], "%d %s", &im, trash);

                    //invalid syntax
                    if (strcmp(trash, "\0")!=0){
                        assemble_fail(1);
                        return;
                    }

                    //if not symbol but int
                    oc *= 16;
                    oc += 1;
                    oc *= pow(16, 5);
                    oc += im;
                }
                //exist symbol
                else{
                    oc *= 16;
                    oc += 1;
                    oc *= pow(16,5);
                    oc += symloc;
                }
                lp_write(linenum, locctr, buffer2, oc, 4);

            }//if word[2][0] == '#' end
            else{
                oc += 3;
                if(word[2][0] == '@'){
                    oc -= 1;
                    strcpy(word[2], word[2]+1);
                }
                
                if (strcmp(word[3], "\0")!=0){
                    word[2][strlen(word[2])-1] ='\0';
                }

                int symloc = find_symbol_loc(word[2]);

                //if symbol not exist
                if (symloc == -1){
                    assemble_fail(1);
                    return;
                }

                //if symbol exist
                else{
                    
                    //identify indexing mode
                    if (strcmp(word[3], "\0")!=0){
                        if (strlen(word[3])>1){
                            assemble_fail(1);
                            return;
                        }
                        if (reg_num[word[3][0]-65]<0){
                            assemble_fail(1);
                            return;
                        }
                        oc *= 16;
                        oc += 8;
                    } 
                    else
                        oc *= 16;
                    oc += 1;
                    oc *= pow(16,5);
                    oc += symloc;
                }
                lp_write(linenum, locctr, buffer2, oc, 4);

                //for modification record
                push_modi(locctr, oc);               

            }
        }
        else{
            assemble_fail(1);
            return;
        }
    }

    //make object file
    print_object_code();
    print_modi_code();
    fprintf(op, "E%06X\n", startaddress);
    store_symbol();

    //free useless data
    free_symtable();
    fclose(imp);
    fclose(lp);
    fclose(op);
    fclose(fp);
    fp = NULL;
    op = NULL;
    lp = NULL;
    imp = NULL;
    his_add();
    
    p = strtok(par[0], ".");
    strcat(p, ".lst");
    printf("[%s], ", p);
    p = strtok(par[0], ".");
    strcat(p, ".obj");
    printf("[%s]\n", p);
}//pass2 end

//pass 1
void pass1(){
    fp = fopen(par[0], "r");
    if (fp == NULL){
        printf("not exist file\n");
        return;
    }
    imp = fopen("immediate", "w");
    
    

    //check file name
    char p[100];
    strcpy(p, par[0]+strlen(par[0])-4);
    if (strcmp(p, ".asm")){
        assemble_fail(6);
        return;
    }

    //init
    locctr = 0;
    linenum = 0;
    memset(program_name, 0, 10);
    for (int i = 0; i < 26; i++){
        reg_value[i] = -1;
    }


    //read asm file
    while( fgets(buffer, 100,fp) != NULL){
        

        //if empty line, continue
        if (strcmp(buffer, "\n")==0) continue;

        //line number increase
        linenum+=5;
        int temp;

        //memory reset
        memset(word, 0, 400);

        //check if line has symbol or not
        if (buffer[0] == ' ' || buffer[0] == '\t'){
            sscanf(buffer, "%s %s %s", word[1], word[2], word[3]);
            temp = 2;
        }
        else{
            sscanf(buffer, "%s %s %s %s", word[0], word[1], word[2], word[3]);
            temp = 3;
        }


        //program start line
        if (strcmp(word[1], "START")==0){
            strcpy(program_name, word[0]);
            sscanf(word[2], "%x", &locctr);
            filesize = locctr;
            startaddress = locctr;
            imp_write(linenum, locctr,buffer);
            continue;
        }


        //if line is comment
        if (buffer[0] == '.'){
            fprintf(imp, "%d %11s %s", linenum,"", buffer);
        }


        //if line has no symbol
        else if (temp == 2){
            
            //get instruction size
            int flag = 0;
            if (word[1][0] == '+'){
                strcpy(word[1], word[1]+1);
                flag = 1;
            }
            int instruction_size = find_mnemonic_format(word[1]);
            
            //if opcode not exist
            if (instruction_size == -1){ 
                if (strcmp(word[1], "BASE")==0){
                    fprintf(imp, "%-6d %15s %-6s %-10s\n", linenum,"", word[1], word[2]);
                }
                else if (strcmp(word[1], "END")==0){
                    fprintf(imp, "%-6d %15s %-6s %-10s\n", linenum,"", word[1], word[2]);
                }
                else if (strcmp(word[1], "NOBASE")==0){
                    fprintf(imp, "%-6d %15s %-6s %-10s\n", linenum, "", word[1], word[2]);
                }
                else{
                    assemble_fail(0);   
                    return;
                }
                continue;
            }
            
            
            //if opcode has 4 format
            if (instruction_size == 3 && flag){
                locctr+=4;
                instruction_size = 4;
            }
            //if opcode has 1, 2, 3 format
            else{
                locctr+=instruction_size;
            }
            
            imp_write(linenum, locctr-instruction_size, buffer);

        }


        //if line has symbol
        else if (temp == 3){


            //get instruction size
            int flag = 0;
            if (word[1][0] == '+'){
                strcpy(word[1], word[1]+1);
                flag = 1;
            }
            int instruction_size = find_mnemonic_format(word[1]);
            int size = 0; 
            
            bool overlap = push_symtable(word[0], locctr);
            //if symbol overlap
            if (!overlap) return;

            //if opcode not exist            
            if (instruction_size == -1){

                if (strcmp(word[1], "WORD")==0){
                    locctr += 3;
                }
                else if (strcmp(word[1], "RESW")==0){
                    sscanf(word[2], "%d", &size);
                    locctr += 3* size;
                }
                else if (strcmp(word[1], "RESB")==0){
                    sscanf(word[2], "%d", &size);
                    locctr += size;
                }
                else if (strcmp(word[1], "BYTE")==0){
                    if (word[2][0] == 'C'){
                        locctr += strlen(word[2]) - 3;
                        size = strlen(word[2])-3;
                    }
                    else if (word[2][0] == 'X'){
                        locctr += (strlen(word[2])-2)/2;
                        size = (strlen(word[2])-2)/2;
                    }
                    else{
                        assemble_fail(1);
                        return;
                    }
                }


                else{
                    assemble_fail(0);
                    return;
                }
                instruction_size = 0;
            }
            //if opcode has 4 format
            else if (instruction_size == 3 && flag){
                locctr += 4;
                instruction_size = 4;
            }
            //if opcode has 1, 2, 3 format
            else{
                locctr += instruction_size;
            }
            imp_write(linenum, locctr-instruction_size-size, buffer);
        }
        //error line
        else{
            assemble_fail(1);
            return;
        }
    }
    
    fclose(imp);
    fclose(fp);
    filesize = locctr-filesize;

    pass2();

}
