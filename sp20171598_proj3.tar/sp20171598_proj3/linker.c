#include "linker.h"
#include "memory.h"
#include "history.h"
#include "hash.h"


FILE *fp[3];
char p[3][100];
int progstartaddr[3];
int proglen;
bool break_flag = 1;
int a, x, l, pc, b, s, t, cc;


//return symbol address
int sym_addr(char* to_find){
    est_node* temp = estab[to_find[0]-65];
    while(temp != NULL){
        if (strcmp(temp->symbol, to_find)==0){
            return temp->address;
        }
        temp = temp->next;
    }
    return -1;
}

//free ESTAB
void estab_free(){
    est_node* x, *y;
    for (int i = 0; i < 26; i++){
        x = estab[i];
        while(x != NULL){
            y = x->next;
            free(y);
            x = y;
        }
        estab[i] = NULL;
    }
    
    estab = (est_node**)calloc(26, sizeof(est_node*));
}

//linking
void linker(int cnt){

    //check file open
    for (int i = 0; i < cnt; i++){
        fp[i] = fopen(par[i], "r");
        if (fp[i] == NULL){
            printf("invalid filel name\n");
            return;
        }   
    }

    printf("control symbol address length\n");
    printf("section name\n");
    printf("---------------------------------\n");

    char t[100];
    
    int nowstart = progaddr;
    int nowlen; 


    for (int i = 0; i < cnt; i++){
        fgets(p[i], 100,  fp[i]);

        //header record
        if (p[i][0] == 'H'){
            //make node
            est_node* now = (est_node*)calloc(1, sizeof(est_node));
            
            //copy control section name
            strncpy(now->symbol, p[i]+1, 6);
            now->symbol[6] = '\0';
            //copy start address
            strncpy(t, &p[i][7], 6);
            t[6] = '\0';

            now->address = nowstart + strtol(t, NULL, 16);
            nowstart = now->address;

            //copy program length
            strncpy(t, &p[i][13], 6);
            t[6] = '\0';
            now->len = strtol(t, NULL ,16);
            nowlen = now->len;

            //symbol type : control section
            now->type = true;
            
            est_node* temp = estab[now->symbol[0]-65];
            if (temp == NULL){
                estab[now->symbol[0]-65] = now;
            }
            else{
                while(temp -> next != NULL) temp = temp->next;
                temp -> next = now;
            }

            printf("%-8s        %04X   %04X\n", now->symbol, now->address, now->len);
        }
        
        while(1){
            fgets(p[i], 100, fp[i]);

            //if not definition record, break
            if (p[i][0] != 'D') break;

            int len = strlen(p[i]);
            //make estab
            for (int j= 1; j < len-1; j += 12){
                //make node
                est_node* now = calloc(1, sizeof(est_node));
                
                //symbol name
                strncpy(now->symbol, p[i]+j, 6);
                now->symbol[6] = '\0';
                for (int k = strlen(now->symbol)-1; k >= 0; k--){
                    if (now->symbol[k] == ' ') {
                        now->symbol[k] = '\0';
                        
                    }
                    
                }
                
                
                //address
                strncpy(t, p[i]+j+6, 6);   
                t[6] = '\0';
                now->address = strtol(t, NULL, 16);
                now->address += nowstart;
                
                //symbol type : symbol
                now->type = false;

                est_node* temp = estab[now->symbol[0]-65];
                if (temp == NULL){
                    estab[now->symbol[0]-65] = now;
                }
                else{
                    while(temp -> next != NULL) temp = temp->next;
                    temp -> next = now;                    
                }
                printf("\t%6s  %04X\n", now->symbol, now->address);
            }
        }
        progstartaddr[i] = nowstart;
        nowstart += nowlen;
    }

    proglen = nowstart;
    printf("---------------------------------\n");
    printf("\t  total length %04X\n", nowstart); 


//print estab finish

//program load

    loader(cnt);

    for (int i = 0; i < cnt; i++){
        fclose(fp[i]);
    }
    memset(p, 0, 300);
    for (int i = 0; i < 3; i++){
        progstartaddr[i] = 0;
    }
    estab_free();
    return;
}


void loader(int cnt){
    
    for (int i =0; i < cnt; i++){

        int arr[266];
        arr[1] = progstartaddr[i];
        while(1){
            //reference record
            if (p[i][0] == 'R'){
                p[i][strlen(p[i])-1] = '\0';
                int len = strlen(p[i]);
                for (int j = 1; j < len; j+=8){
                    //parsing sentence
                    char num[5];
                    strncpy(num, p[i]+j, 2);
                    num[2] = '\0';
                    char name[8];
                    strncpy(name, p[i]+j+2, 6);
                    name[6] = '\0';
                    for (int k = 0; k < 8; k++){
                        if (name[k] == ' '){
                            name[k] = '\0';
                            break;
                        }
                    }
                    //store refrence number
                    arr[strtol(num, NULL, 16)] = sym_addr(name);
                }

            }
            //text record
            else if (p[i][0] == 'T'){
                //parsing sentence
                int startaddr;
                char num[8];
                strncpy(num, p[i]+1, 6);
                num[6] = '\0';
                startaddr = strtol(num, NULL, 16);
                int len;
                strncpy(num, p[i]+7, 2);
                num[2] = '\0';
                len = strtol(num, NULL, 16);

                //load to memory
                for (int j = 9, k = 0; k < len; j += 2){
                    strncpy(num, p[i]+j, 2);
                    num[2] = '\0';
                    //printf("%d\n", progstartaddr[i] + startaddr + k);
                    memory[progstartaddr[i] + startaddr + k] = strtol(num, NULL, 16);
                    k += 1;
                }
            }
            //modification record
            else if (p[i][0] == 'M'){
                //parsing sentence
                int startaddr, len, add;
                char num[8];

                strncpy(num, p[i]+1, 6);
                num[6] = '\0';
                startaddr = strtol(num, NULL, 16);
                
                strncpy(num, p[i]+7, 2);
                num[2] = '\0';
                len = strtol(num, NULL, 16);
                
                strncpy(num, p[i]+10, 2);
                num[2] = '\0';
                add = strtol(num, NULL, 16);
                
                add = arr[add];
                unsigned int original = 0;
                int k;

                //modify memory
                for (k = 0; len > 0; len -= 2){
                    original *= 16*16;
                    original += memory[progstartaddr[i] + startaddr + k++];
                }
                if (p[i][9] == '+'){
                    original += add;
                }
                else if (p[i][9] == '-'){
                    original -= add;
                }
                k -= 1;
                while(k >= 0){
                    memory[progstartaddr[i] + startaddr + k--] = original % (16*16);
                    original /= (16*16);
                }
            }
            else if (p[i][0] == 'E'){
                break;
            }
    
            
            fgets(p[i], 100,  fp[i]);
            if (p[i] == NULL) break;

        }
    }

    his_add();
    //register init
    linkerflag = 0;
    a = 0;
    x = 0;
    l = proglen;
    pc = progaddr;
    b = 0;
    s = 0;
    t = 0;
    cc = 0;
}

//store x, b, p, e addressing mode
//1 : set
int addressing[4];


//input : register number
//output : register address
int* regnum(int num){
    if (num == 0){
        return &a;
    }
    else if (num == 1){
        return &x;
    }
    else if (num == 2) return &l;
    else if (num == 3) return &b;
    else if (num == 4) return &s;
    else if (num == 5) return &t;
    else if (num == 8) return &pc;
    else return &cc;
}


//run
void run(){
    while(pc < proglen){
        //check break point
        for (int i =0; i < bpcnt; i++){
            if (pc == bp[i] && break_flag){
                break_flag = 0;
                printf("A : %06X  X : %06X\n", a, x);
                printf("L : %06X PC : %06X\n", l, pc);
                printf("B : %06X  S : %06X\n", b, s);
                printf("T : %06X\n", t);
                printf("\t Stop at checkpoint[%X]\n", pc);
                his_add();
                return;
            }
        }
        break_flag = 1;

        //move pc and get now instruction
        int nowopcode = memory[pc] - memory[pc]%4;   
        int nowloc = pc;
        int nowformat = find_opcode_mnemonic(nowopcode);        
        if(nowformat==1){
            pc += 1;
        }
        else if (nowformat==2){
            pc += 2;
        }
        else if (nowformat==3){
            if (memory[pc+1]/16 == 1){
                pc += 4;
                nowformat = 4;
            }
            else
                pc += 3;
        }

        //get n, i 
        int ni = memory[nowloc]%4;
        

        if (nowformat == 2){
            //clear
            if (nowopcode == 0xB4){
                int* r1 = regnum(memory[nowloc+1]/16);
                *r1 = 0;
            }
            //compr
            else if (nowopcode == 0xA0){
                int *r1, *r2;
                r1= regnum(memory[nowloc+1]/16);
                r2 = regnum(memory[nowloc+1]%16);
                *r1 =0;
                *r2 = 0;
                if (*r1 < *r2) cc = -1;
                else if(*r1 == *r2) cc = 0;
                else cc = 1;
            }
            //tixr
            else if (nowopcode == 0xB8){
                x += 1;
                int* r1 = regnum(memory[nowloc+1]/16);
                if (x < *r1) cc = -1;
                else if (x == *r1) cc = 0;
                else cc = 1;
            }
        }
        else if (nowformat >= 3){
            int div = 128;
            for (int i = 0; i < 4; i++){
                addressing[i] = memory[nowloc+1] & div;
                addressing[i] /= div;
                div /= 2;
            }
            int addr = 0;
            addr += memory[nowloc+1]%16;
            addr *= 16*16;
            addr += memory[nowloc+2];
            if (nowformat == 4){
                addr *= 16*16;
                addr += memory[nowloc+3];
            }
            if (addressing[2] == 1){
                if (addr >= 16*16*8){
                    addr = 16*16*16 - addr;
                    addr *= -1;
                }
            }
            //STL
            if (nowopcode == 0x14){
                if (ni == 3){
                    if (addressing[2] == 1){
                        memory[addr + pc] = (l&(0xFF0000))>>16;
                        memory[addr + pc + 1] = (l&(0xFF00))>>8;
                        memory[addr + pc + 2] = l&(0xFF);
                    }
                }
            }
            //LDB
            else if (nowopcode == 0x68){
                if (ni == 1){
                    if (addressing[2] == 1)
                        b = addr + pc;
                }
            }
            //JSUB
            else if (nowopcode == 0x48){
                if (ni == 3){
                    if (nowformat == 4){
                        l = pc;
                        pc = addr;
                    }
                }
            }
            //LDA
            else if (nowopcode == 0x00){
                if (ni == 1){
                    a = addr;
                }
                else if (ni == 3){
                    if (addressing[2] == 1){
                        a = memory[pc + addr];
                        a *= 16*16;
                        a += memory[pc+addr+1];
                        a *= 16*16;
                        a += memory[pc+addr+2];
                    }
                }

            }
            //COMP
            else if (nowopcode == 0x28){
                if (ni == 1){
                    if (a < addr) cc = -1;
                    else if (a == addr) cc = 0;
                    else cc = 1;
                }
            }
            //JEQ
            else if (nowopcode == 0x30){
                if (ni == 3){
                    if (addressing[2] == 1){
                        if (cc == 0){
                            pc += addr;
                        }
                    }
                }       
            }
            //J
            else if (nowopcode == 0x3C){
                if (ni == 3){
                    if (addressing[2] == 1){
                        pc += addr;
                    }
                }
                if (ni == 2){
                    if (addressing[2] == 1){
                        int nextaddress =0;
                        nextaddress += memory[pc+addr];
                        nextaddress *= 16*16;
                        nextaddress += memory[pc+addr+1];
                        nextaddress *= 16*16;
                        nextaddress += memory[pc+addr+2];
                        pc = nextaddress;
                    }
                }
            }
            //STA
            else if (nowopcode == 0x0C){
                if (ni == 3){
                    if (addressing[2] == 1){
                        memory[addr + pc] = (a&(0xFF0000))>>16;
                        memory[addr + pc + 1] = (a&(0xFF00))>>8;
                        memory[addr + pc + 2] = a&(0xFF);
                    }
                }
            }
            //LDT
            else if (nowopcode == 0x74){
                if (ni == 1){
                    t = addr;
                }
                else if (ni == 3){
                    t = memory[b + addr];
                    t *= 16*16;
                    t += memory[b + addr + 1];
                    t *= 16*16;
                    t += memory[b + addr + 2];
                }
            }
            //TD
            else if (nowopcode == 0xE0){
                cc = -1;
            }
            //RD
            else if (nowopcode == 0xD8){
                a = 0; s = 0;
            }
            //STCH
            else if (nowopcode == 0x54){
                if (ni == 3){
                    if (addressing[0] == 1){
                        if (addressing[1] == 1){
                            memory[b+addr+x+2] = a;
                        }
                    }
                }
            }
            //JLT
            else if (nowopcode == 0x38){
                if (ni == 3){
                    if (cc == -1){
                        pc += addr;
                    }                    
                }
            }
            //STX
            else if (nowopcode == 0x10){
                if (ni == 3){
                    if (addressing[1] == 1){
                        memory[addr + b] = (x&(0xFF0000))>>16;
                        memory[addr + b + 1] = (x&(0xFF00))>>8;
                        memory[addr + b + 2] = x&(0xFF);
                    }
                }       
            }
            //RSUB
            else if (nowopcode == 0x4C){
                pc = l;
            }
            //LDCH
            else if (nowopcode == 0x50){
                if (ni == 3){
                    if (addressing[0]){
                        if (addressing[1]){
                            a = memory[b + addr + x];
                        }
                    }
                }
            }
            //WD
            else if (nowopcode == 0xDC){
                continue;    
            }


        }
                
    }
    printf("A : %06X  X : %06X\n", a, x);
    printf("L : %06X PC : %06X\n", l, pc);
    printf("B : %06X  S : %06X\n", b, s);
    printf("T : %06X\n", t);
    printf("\tEnd Program\n");
    his_add();
}
