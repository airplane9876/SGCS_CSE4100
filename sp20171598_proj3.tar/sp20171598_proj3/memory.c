#include "memory.h"
#include "history.h" // to use his_add()


//process dump input
void print_dump(int start, int end){
    if (start < 0 || end >= MEMORYSIZE || start > end){
        printf("invalid range\n");
        return;
    }
    his_add();
    for (int i = start - start%16; i <= end-end%16+15; i++){
        //front of row
        if (i%16 == 0){
            printf("%05X ", i);
        }

        //print element
        if (start <= i && i <= end)
            printf("%02X ", memory[i]);
        else printf("   ");

        //end of row
        if (i%16 == 15){
            printf("; ");
            for (int j = i-15; j <= i; j++){
                if (memory[j] < 0x20 || memory[j] > 0x7E || j < start || j > end)
                    printf(".");
                else
                    printf("%c", memory[j]);
            }
            printf("\n");
        }
    }
    return; 
}//print_dump end


//process reset input
void reset(){
    memset(memory, 0, MEMORYSIZE);
}


//process edit input
void edit(int idx, int v){
    if (v < 0 || v > 0xFF || idx < 0 || idx > 0xFFFFF){
        printf("invalid value\n");
        return;
    }
    memory[idx] = v;
    his_add();
    return;
}


//process fill input
void fill(int start, int end, int v){
    if (v < 0 || v > 0xFF || end < 0 || start > 0xFFFFF || end < start){
        printf("invalid value\n");
        return;
    }
    for (int i = start; i <= end; i++){
        memory[i] = v;
    }
    his_add();
    return;
}
