#include "20171598.h"

//var
int progaddr, bpcnt, linkerflag;
int bp[1000];

typedef struct est_node{
    char symbol[10];
    bool type;
    int address;
    int len;
    struct est_node* next;
}est_node;

est_node** estab;

//func
void linker(int cnt);
void loader(int cnt);
void run();
