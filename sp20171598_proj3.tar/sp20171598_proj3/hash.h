#include "20171598.h"

typedef struct node{
	char mnemonic[10];
	int num;
    char format[10];
	struct node* next;
}node;

node** hashTable;

void make_hashtable();

int find_hashvalue(char* a);

void print_hashtable();

void find_mnemonic(char* to_find);

int find_mnemonic_format(char* to_find);

int find_mnemonic_opcode(char* to_find);

int find_opcode_mnemonic(int opcode);
