#include "history.h"
#include "linker.h"
//build history list
void his_add(){
	history_node* now = malloc(sizeof(history_node));	
	
	//init
    if (parnum >= 0){
	    strcpy(now->command, command_for_history);        
    }
    if (parnum >= 1){
        strcat(now->command, " ");
        strcat(now->command, par_for_history[0]);
    }
    if (parnum >= 3){
        if (linkerflag) strcat(now->command, " ");
        else strcat(now->command, ", ");
        strcat(now->command, par_for_history[1]);
    }
    if (parnum >= 5){
        if (linkerflag) strcat(now->command, " ");
        else strcat(now->command, ", ");
        strcat(now->command, par_for_history[2]);
    }
	now->next = NULL;
    //init end


	history_node* temp = history;
	
    //push to linked_list
	if (temp == NULL){
		now->num = 1;
		history = now;
	}
	else{
		while(temp->next != NULL){ 
			temp = temp->next;
		}
		now->num = temp->num + 1;
		temp->next = now;
	}
}//his_add end



//process history command
void his(){
	history_node* now = history;
	while(now != NULL){
		printf("%-5d%s\n", now->num, now->command);
		now = now->next;
	}
}
